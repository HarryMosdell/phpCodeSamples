<main class="home">
<p>FAQs coming soon </p>
</main >
