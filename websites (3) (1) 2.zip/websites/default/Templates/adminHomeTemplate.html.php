<main class="admin">

  <h2>Log in</h2>

  <form action="" method="post" style="padding: 40px">
    <label>Enter User Name</label>
    <input type="text" name="userName" />
    <label>Enter Password</label>
    <input type="password" name="password" />

    <input type="submit" name="submit" value="Log In" />
  </form>

</main>
